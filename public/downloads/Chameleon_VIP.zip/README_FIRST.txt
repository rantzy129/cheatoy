================================================================================
          CHAMELEON VIP — ASSAULT FIRE PH ADVANCED SILHOUETTE CHAMS
================================================================================
Official Portal: https://www.chameleon-cheats.tech/
Status         : Undetected (Bypass Active)
USE IT AT YOUR OWN RISK

================================================================================
  1. QUICK START INSTRUCTIONS
================================================================================
IMPORTANT: Ensure Assault Fire PH is running in WINDOWED MODE before injecting.

1. Extract all files from this archive into a private folder (e.g., on your Desktop).
2. Right-click 'Chameleon.exe' and select 'Run as Administrator'. 
   *(You must run the loader as Admin for the injection to work).*
3. Enter your VIP License Key.
4. Enter your bound Discord Username or Snowflake ID.
5. The loader will verify your access credentials.
6. Launch Assault Fire PH (Legacy / Reborn).
7. The loader will detect the game launch and inject automatically.
8. Keep the loader console open in the background while playing.

================================================================================
  2. IN-GAME CONTROLS & HOTKEYS
================================================================================
- [INSERT] : Toggle In-Game VIP Menu (Wallhack, Chams, Health Bar, 2D Box, Aimbot)
- Use your mouse or arrow keys inside the VIP menu to customize visual settings,
  box thickness, health display, and occlusion chams colors in real-time.

** CONFIGURATION NOTE: **
By default, your screen will appear Blue because the Chams feature is enabled. 
If you do not want to use Chams, simply open the VIP menu and disable it. 
Your Wallhack, Snaplines, and 2D Boxes will still work perfectly.

** AIMBOT DISCLAIMER: **
The Aimbot feature is provided as-is. Using the Aimbot drastically increases your 
risk of being reported by other players or flagged by anti-cheat systems. 
USE THE AIMBOT AT YOUR OWN RISK. We are not responsible for account bans.

================================================================================
  3. TERMS OF SERVICE & USAGE CONDITIONS (STRICT ENFORCEMENT)
================================================================================
Please read these terms carefully before utilizing your VIP access key:

[1] STRICTLY 1 KEY = 1 PC (HARDWARE SECURED)
    Each Chameleon VIP license is strictly bound to ONE PC and locked to your
    unique Machine Hardware ID (HWID) and Discord account. Sharing, renting,
    reselling, or leaking license keys is strictly prohibited.

[2] AUTOMATED HWID MISMATCH DETECTION & BAN RISK
    Attempting to activate your license on multiple devices simultaneously or
    swapping PCs without an authorized HWID reset will immediately flag your
    account and result in automated license suspension.

[3] ZERO TOLERANCE POLICY
    Any attempt to tamper with the software, bypass authentication,
    or share account credentials will result in immediate and permanent
    license revocation and blacklist across our network with zero refund.

[4] NO REFUND POLICY
    All sales are final. We do not offer refunds under any circumstances, 
    including but not limited to: user hardware changes, game updates breaking 
    the software temporarily, or account bans resulting from user negligence.

================================================================================
  4. SUPPORT & LICENSE RENEWALS
================================================================================
Need a legitimate HWID reset, renewal, or technical assistance?
- Official Website: https://www.chameleon-cheats.tech/
- Member Vault    : Sign in with Discord on our web portal to check license status
================================================================================
