﻿==================================================
        CHAMELEON CHEATS - VIP INSTALLATION
        Assault Fire PH (Legacy / Reborn)
==================================================

QUICK START:
1. Extract ALL files from this zip to a private folder
   (e.g., Desktop or Documents).
2. Right-click "Chameleon.exe" -> Select "Run as administrator".
3. Enter your VIP License Key when prompted.
4. Launch Assault Fire PH (TGame.exe).
5. The memory injection occurs automatically with zero disk trace.
6. Press [INSERT] in-game to toggle the VIP Menu.

NOTE:
- Do not run reverse engineering tools (x64dbg, Cheat Engine, IDA)
  while running the loader, or it will auto-close for security.
==================================================
