=====================================================
   CHAMELEON VIP - ASSAULT FIRE PH UNDETECTED CHAMS
=====================================================

INSTRUCTIONS:
1. Extract Chameleon.exe to any private folder (e.g. Desktop).
2. Right-click Chameleon.exe and select 'Run as Administrator'.
3. Enter your VIP License Key (or paste it into license.txt).
4. Enter your Discord Username or Snowflake ID.
5. Launch Assault Fire PH.
6. The injector will automatically detect game launch and inject!

IN-GAME CONTROLS:
- [F7]     : Cycle Chams Color (Rainbow / Red / Cyan / Green / Purple / Orange / Yellow)
- [F8]     : Toggle Chams On / Off
- [INSERT] : Toggle Snaplines

Need assistance or license renewal?
Visit: https://cheatoy.vercel.app/
